#include <cmath>
#include <iostream>

#include "RKSolver.hpp"


RKSolver::RKSolver(double step, const BaseEquation &eq,
                   const std::vector<std::vector<double>> &a_,
                   const std::vector<double> &b_,
                   const std::vector<double> &c_,
                   double tolerance, double min_step)
    : h(step), equation(eq), a(a_), b(b_), c(c_), tol(tolerance), hmin(min_step)
{
    assert(b.size() == c.size() && a.size() == a[0].size() && b.size() == a.size());
    n_stages = b.size();
    method_name = "User defined";
    // The solution at t=0 coincides with the initial condition
    solution.push_back( equation.get_x0() );
    times.push_back( equation.get_tin() );
}

Rnvector RKSolver::fixed_point(const EquationFunction &f, const double tn,
                               const Rnvector &un, const double h_local,
                               const Rnvector &sum_aij_Kj, const size_t i) const
{
    unsigned n_iter = 0;
    unsigned Max_iter = 10000;

    Rnvector K0 = un;
    Rnvector K1 = f.eval(tn + c[i] * h_local,
                    un + h_local * sum_aij_Kj + h_local * a[i][i] * K0);
    double error = compute_error(K0, K1);
    K0 = K1;

    while (error > fixed_point_tol && n_iter < Max_iter)
    {
        K1 = f.eval(tn + c[i] * h_local,
               un + h_local * sum_aij_Kj + h_local * a[i][i] * K0);
        error = compute_error(K0, K1);
        K0 = K1;
        n_iter++;
    }

    if (n_iter == Max_iter)
    {
        std::cerr << "Fixed point algorithm cannot converge. Try with a smaller step size."
                  << std::endl;
        exit(1);
    }

    return K0;
}

double RKSolver::compute_error(const Rnvector &K0, const Rnvector &K1) const
{
    double error = 0;
    for (size_t k = 0; k < K0.size(); k++)
        error += std::abs(K0[k] - K1[k]);
    return error;
}

bool RKSolver::is_implicit(const size_t K_index) const
{
    return (a[K_index][K_index] != 0);
}

void RKSolver::print() const
{
    // Print the equation
    std::cout << "Equation:" << std::endl;
    std::cout << equation.get_f().f_string << "\t in [" <<
    equation.get_tin() << "," << equation.get_tfin() << "]" << std::endl;
    std::cout << "y(" << equation.get_tin() << ") = ";
    for( auto i : equation.get_x0() )
        std::cout << i << " ";
    std::cout << std::endl << std::endl;
    //Print the solver specifications
    print_solver_spec();
}

void RKSolver::save_sol_to_file( const std::string &file_name ) const
{
    std::ofstream output_stream{ file_name };
    if( !output_stream )
    {
        std::cerr << "Cannot open input file: \"" << file_name << "\"" <<
            std::endl;
        return;
    }

    // Save the computed solution
    output_stream << "Solution:" << std::endl;
    for( auto un : solution )
    {
        for( auto val : un )
            output_stream << val << " ";
        output_stream << std::endl;
    }

    // Save time instants
    output_stream << "Time instants:" << std::endl;
    for( auto tn : times )
        output_stream << tn << " ";
    output_stream << std::endl;
}

void RKSolver::print_solver_spec() const
{
    std::cout << "Solved using: Adaptive Runge-Kutta (" << method_name << ")" << std::endl;
    std::cout << "Starting h = " << h << std::endl;
    std::cout << "Minimum h  = " << hmin << std::endl;
    std::cout << "Tolerance  = " << tol << std::endl;
    std::cout << std::endl;
}

Rnvector RKSolver::single_step(const double tn, const Rnvector &un,
    const double hn) const
{
    // Your code goes here
    // N.B.: the initial condition (t_0, u_0) has already been included in the
    // `times` and `solution` vectors by the class constructor (see above)

    Rnvector sum_aij_Kj(equation.get_dimension(), 0.0);
    Rnvector Ktmp(equation.get_dimension(), 0.0);
    std::vector<Rnvector> K;

    for (unsigned int i = 0; i < n_stages; ++i)
    {
        for (unsigned int j = 0; j < i; ++j)
        {
            sum_aij_Kj = sum_aij_Kj + a[i][j] * K[j];
        }
        if (is_implicit(i))
        {
            Ktmp = fixed_point(equation.get_f(), tn, un, hn, sum_aij_Kj, i);
            K.push_back(Ktmp);
        }
        else
        {
            Ktmp = equation.get_f().eval(tn + c[i] * hn, un + hn * sum_aij_Kj);
            K.push_back(Ktmp);
        }
    }

    Rnvector unp1(un);
    for (unsigned int i = 0; i < n_stages; ++i)
    {
        unp1 = unp1 + hn * b[i] * K[i];
    }

    return unp1;
}

void RKSolver::solve()
{
    // Your code goes here
    unsigned int n = 0;
    double hn = h;
    double t0 = equation.get_tin();
    double tF = equation.get_tfin();
    double tn = t0;
    times.push_back(tn);
    solution.push_back(equation.get_x0());

    Rnvector uhn1(equation.get_dimension(), 0.0);
    Rnvector uhn2(equation.get_dimension(), 0.0);
    Rnvector uhnabsdiff(equation.get_dimension(), 0.0);
    Rnvector unabs(equation.get_dimension(), 0.0);
    std::vector<double> E;

    while (tn + hn <= tF)
    {
        //std::cout << "while" << std::endl;
        uhn1 = single_step(tn, solution[n], hn);
        uhn2 = single_step(tn+hn/2, single_step(tn, solution[n], hn/2), hn/2);

        //std::cout << "single step" << std::endl;
        uhnabsdiff = abs(uhn1-uhn2);
        unabs = abs(solution[n]);

        E.push_back( *std::max_element( uhnabsdiff.begin(), uhnabsdiff.end() )
                        / *std::max_element( unabs.begin(), unabs.end() ) );
        //std::cout << "E[" << n << "] = " << E[n] << "   " << "hn = " << hn << std::endl;

        if (E[n] < tol/2 || hn < hmin)
        {
            //std::cout << "if" << std::endl;
            tn = tn+hn;
            times.push_back(tn);
            solution.push_back(uhn2);
            if (E[n]<tol/exp2(n_stages+1))
                hn = 2*hn;
            n = n + 1;
        }
        else
        {
            //std::cout << "else" << std::endl;
            hn = hn/2;
        }

    }
    //std::cout << "So far so good" << std::endl;
    hn = tF - tn;
    if (hn > (tF-t0)/pow(10, 3))
    {
        times.push_back(tF);
        solution.push_back(single_step(tn+hn/2, single_step(tn, solution[n], hn/2), hn/2));
    }
}